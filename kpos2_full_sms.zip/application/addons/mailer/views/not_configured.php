<form method="post" class="form-horizontal">

	<div class="headerbar">
		<h1><?php echo lang('email_invoice'); ?></h1>
	</div>
	
	<div class="content">
		<p><?php echo lang('email_not_configured'); ?></p>
	</div>

</form>