<div class="pull-right">
	<button class="btn btn-primary" name="btn_submit" value="1"><i class="icon-ok icon-white"></i> <?php echo lang('save'); ?></button>
    <button class="btn btn-danger" name="btn_cancel" value="1"><i class="icon-remove icon-white"></i> <?php echo lang('cancel'); ?></button>
</div>