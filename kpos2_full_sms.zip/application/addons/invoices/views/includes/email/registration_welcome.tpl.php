<html>
<body>
	<h1>Thankyou for Registering to InstaInvoice!</h1>
	
	<p>You login identity is: <?php echo $identity;?></p>
</body>
</html>