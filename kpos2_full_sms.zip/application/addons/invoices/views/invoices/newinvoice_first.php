<?php
$this->load->view('header');

$this->load->view('invoices/invoice_new');

$this->load->view('footer');
?>