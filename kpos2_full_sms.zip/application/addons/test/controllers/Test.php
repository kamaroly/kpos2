<?php
Class Test extends  Base_Controller
{
	function index()
	{
		echo 'Hello World!';
	}
}