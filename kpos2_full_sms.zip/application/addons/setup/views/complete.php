<div class="install-step">
	
	<h1>InstaInvoice</h1>

	<h2><?php echo lang('setup_complete'); ?></h2>
	
	<p><span class="label label-success"><?php echo lang('success'); ?></span> <?php echo lang('setup_complete_message'); ?></p>
	
	<?php echo anchor('sessions/login', lang('login'), array('class'=>'btn btn-primary')); ?>
	
</div>