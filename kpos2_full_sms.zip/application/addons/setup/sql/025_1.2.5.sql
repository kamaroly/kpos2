ALTER TABLE `fi_custom_fields` CHANGE `custom_field_label` `custom_field_label` VARCHAR( 64 ) NOT NULL ,
CHANGE `custom_field_column` `custom_field_column` VARCHAR( 64 ) NOT NULL 